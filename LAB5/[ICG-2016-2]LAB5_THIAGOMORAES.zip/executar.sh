#/bin/bash

g++ questao1.cpp -o saida1 -lglut -lGLU -lGL -lm
./saida1

g++ questao2.cpp -o saida2 -lglut -lGLU -lGL -lm
./saida2

g++ questao3.cpp -o saida3 -lglut -lGLU -lGL -lm
./saida3

g++ questao4.cpp -o saida4 -lglut -lGLU -lGL -lm
./saida4


